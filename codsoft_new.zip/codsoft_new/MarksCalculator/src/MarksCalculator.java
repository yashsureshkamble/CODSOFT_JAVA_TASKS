import java.util.Scanner;

public class MarksCalculator {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("Enter the number of subjects:");
            int numsubjects = scanner.nextInt();
            int[] marks = new int[numsubjects];
            int totalMarks = 0;

            for (int i = 0; i < numsubjects; i++) {
                System.out.println("Enter marks" + (i + 1));
                marks[i] = scanner.nextInt();
                totalMarks += marks[i];
            }

            double averagePercentage = (double) totalMarks / numsubjects;

            String grade;
            if (averagePercentage >= 90) {
                grade = "A";
            } else if (averagePercentage >= 80 && averagePercentage <= 90) {
                grade = "B";

            } else if (averagePercentage >= 70 && averagePercentage <= 80) {
                grade = "C";
            } else if (averagePercentage >= 60 && averagePercentage <= 70) {
                grade = "D";

            } else {
                grade = "F";
            }

            System.out.println("Results:");
            System.out.println("Total Marks:" + totalMarks);
            System.out.println("Average Percentage:" + averagePercentage + "%");
            System.out.println("Grade:" + grade);
        }
    }
}
